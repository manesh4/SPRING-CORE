package com.becoder.sterotype;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("com/becoder/sterotype/config.xml");

		Emp em = context.getBean("employee", Emp.class);
		System.out.println(em.hashCode());
		System.out.println(em);

		//sterotype--> sterotype annotation are typically used to simplify the configiration of spring components by providing a set of
		//default values and behaviours that are common to  particuler role.
		
		Emp em2 = context.getBean("employee", Emp.class);
		System.out.println(em2.hashCode());
		System.out.println(em2);
	}

}

package com.becoder.javaconfig;

public class Address {

	private String name;

	public Address(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Address [name=" + name + "]";
	}

}

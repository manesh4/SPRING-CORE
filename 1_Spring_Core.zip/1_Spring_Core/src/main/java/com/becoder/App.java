package com.becoder;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

	}
}
